#include<stdio.h>

int main()
{
    int num=10;
    while (num!=0)
    {
        printf("/n%d",&num);
        num = num - 1;

    }
    return 0;
}